Original MOD: Ars Nouveau
Original Author: baileyholl
Copyright (C) Bailey Hollingsworth
Official Distribution: https://modrinth.com/mod/ars-nouveau
Official Repository: https://github.com/baileyholl/Ars-Nouveau

--------------------------------------------------
Japanese Translation (Non-official) / 日本語化リソースパック (非公式)
Copyright (C) 2026 Mine-Tech
Website: https://www.mine-blog.tech/
Modification Date: 2026-05-23
Modified Content: Translated language files (added/modified ja_jp.json based on en_us.json)
--------------------------------------------------

License / ライセンス:
This resource pack is a derivative work containing translated language files based on the original mod.
It does NOT include the original mod itself, which must be downloaded separately.
This resource pack is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 3 of the License.
This resource pack is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License (LICENSE.txt) along with this program. If not, see <https://www.gnu.org/licenses/>.

(日本語訳)
本リソースパックはオリジナルMODの言語ファイルを翻訳した派生物であり、MOD本体（.jar）は含まれていません。
動作には公式ページからのオリジナルMODの導入が別途必要です。
本リソースパックはフリーソフトウェアです。あなたは、フリーソフトウェア財団が発行する GNU 一般公衆利用許諾契約書（バージョン3）の定める条件の下で、これを再頒布および/または改変することができます。
本リソースパックは有用であることを願って頒布されますが、全くの無保証です。商品性や特定の目的に対する適合性の暗黙の保証を含め、いかなる保証もありません。詳細は同梱の LICENSE.txt をご参照ください。

■ 注意事項 / Important Notice
・本リソースパック（日本語化ファイル）の使用により生じたいかなる損害についても、制作者（Mine-Tech）および元のMOD制作者は一切の責任を負いません。
・本リソースパックは非公式なものであり、個別のサポートやアップデートの義務は負いません。
・本リソースパックに関する質問や不具合報告を、元のMOD制作者へ送ることは絶対におやめください。